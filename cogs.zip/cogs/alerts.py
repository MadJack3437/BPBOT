import discord
from discord.ext import commands
from discord import app_commands

class RedEmbedView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Acknowledge", style=discord.ButtonStyle.danger, custom_id="acknowledge_button")
    async def acknowledge_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            f"✅ {interaction.user.mention} acknowledged the alert!",
            ephemeral=True
        )

class Alerts(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="alert", description="Send a red alert embed with an acknowledge button")
    async def alert(self, interaction: discord.Interaction, message: str):
        embed = discord.Embed(
            title="🚨 Red Alert",
            description=message,
            color=discord.Color.red()
        )
        embed.set_footer(
            text=f"Triggered by {interaction.user.display_name}",
            icon_url=interaction.user.display_avatar.url
        )
        embed.timestamp = interaction.created_at

        view = RedEmbedView()
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(Alerts(bot))
