
import discord
from discord.ext import commands
from discord import app_commands
import db

ADMIN_USER_ID = 495587491697655829  # Replace with your admin user ID

def is_admin():
    async def predicate(interaction: discord.Interaction):
        return interaction.user.id == ADMIN_USER_ID
    return app_commands.check(predicate)

class AdminPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @is_admin()
    @app_commands.command(name="clear-ops", description="Clear all operator ratings")
    async def clear_ops(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        await db.clear_ops()
        from op_ratings import refresh_op_embed
        await refresh_op_embed(self.bot)
        await interaction.followup.send("✅ All operator ratings have been cleared.", ephemeral=True)

    @is_admin()
    @app_commands.command(name="edit-op", description="Edit an operator rating")
    @app_commands.describe(user="User to edit (ID or mention)", rating="New rating 1 to 10", comment="Optional new comment")
    async def edit_op(self, interaction: discord.Interaction, user: str, rating: int, comment: str = ""):
        await interaction.response.defer(ephemeral=True)
        user_id = None
        if user.isdigit():
            user_id = int(user)
        elif user.startswith("<@") and user.endswith(">"):
            user_id = int(user.strip("<@!>"))
        else:
            await interaction.followup.send("❌ Invalid user input.", ephemeral=True)
            return
        if not (1 <= rating <= 10):
            await interaction.followup.send("❌ Rating must be between 1 and 10.", ephemeral=True)
            return

        await db.add_or_update_op(user_id, rating, comment)
        from op_ratings import refresh_op_embed
        await refresh_op_embed(self.bot)
        await interaction.followup.send(f"✅ Updated rating for <@{user_id}>.", ephemeral=True)

    @is_admin()
    @app_commands.command(name="delete-op", description="Delete an operator rating")
    @app_commands.describe(user="User to delete rating for (ID or mention)")
    async def delete_op(self, interaction: discord.Interaction, user: str):
        await interaction.response.defer(ephemeral=True)
        user_id = None
        if user.isdigit():
            user_id = int(user)
        elif user.startswith("<@") and user.endswith(">"):
            user_id = int(user.strip("<@!>"))
        else:
            await interaction.followup.send("❌ Invalid user input.", ephemeral=True)
            return

        await db.delete_op(user_id)
        from op_ratings import refresh_op_embed
        await refresh_op_embed(self.bot)
        await interaction.followup.send(f"✅ Deleted rating for <@{user_id}>.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(AdminPanel(bot))
