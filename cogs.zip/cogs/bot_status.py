import discord
from discord import app_commands
from discord.ext import commands
import psutil
import datetime
import json
import os
import aiofiles
import logging

import db  # your async db module

logger = logging.getLogger('discord')

STATUS_MESSAGE_FILE = "status_messages.json"

# Replace these with your actual admin Discord user IDs
ADMIN_USER_IDS = {
    495587491697655829,
    556772850984419350,
    560708890753368068,
    # Add more IDs here
}

def is_admin():
    async def predicate(interaction: discord.Interaction):
        return interaction.user.id in ADMIN_USER_IDS
    return app_commands.check(predicate)


class StatusDashboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.launch_time = datetime.datetime.utcnow()
        self.status_messages = {}

    async def cog_load(self):
        self.status_messages = await self.load_status_messages()

    async def load_status_messages(self):
        if os.path.exists(STATUS_MESSAGE_FILE):
            async with aiofiles.open(STATUS_MESSAGE_FILE, "r") as f:
                data = await f.read()
                return json.loads(data)
        return {}

    async def save_status_messages(self):
        async with aiofiles.open(STATUS_MESSAGE_FILE, "w") as f:
            await f.write(json.dumps(self.status_messages))

    @is_admin()
    @app_commands.command(name="status-create", description="Create the status embed message in a specific channel")
    @app_commands.describe(channel="The channel where the status message will be posted")
    async def status_create(self, interaction: discord.Interaction, channel: discord.TextChannel):
        logger.info(f"Running /status-create in guild {interaction.guild.id} by user {interaction.user.id} for channel {channel.id}")
        try:
            await interaction.response.defer(ephemeral=True)

            if not channel.permissions_for(interaction.guild.me).send_messages:
                await interaction.followup.send("I don't have permission to send messages in that channel.", ephemeral=True)
                return

            embed = await self.build_status_embed(interaction.guild)
            new_msg = await channel.send(embed=embed)

            guild_id = str(interaction.guild.id)
            channel_id = str(channel.id)

            self.status_messages.setdefault(guild_id, {})[channel_id] = {
                "message_id": new_msg.id
            }
            await self.save_status_messages()

            await interaction.followup.send(f"Status message created in {channel.mention}!", ephemeral=True)
            logger.info(f"Status message created in channel {channel.id} for guild {interaction.guild.id}")

        except Exception as e:
            logger.error(f"Failed to create status message in channel {channel.id}: {e}", exc_info=True)
            if not interaction.response.is_done():
                await interaction.response.send_message(f"Error creating status message: {e}", ephemeral=True)
            else:
                await interaction.followup.send(f"Error creating status message: {e}", ephemeral=True)

    @is_admin()
    @app_commands.command(name="status-update", description="Update all existing status embed messages across all guilds and channels")
    async def status_update(self, interaction: discord.Interaction):
        logger.info(f"Running /status-update by user {interaction.user.id}")

        await interaction.response.defer(ephemeral=True)

        updated = 0
        failed = []

        # Use only guilds the bot is currently in
        for guild in self.bot.guilds:
            guild_id = str(guild.id)
            if guild_id not in self.status_messages:
                continue  # No stored messages for this guild

            channels = self.status_messages[guild_id]
            for channel_id, msg_info in list(channels.items()):
                channel = guild.get_channel(int(channel_id))
                if not channel:
                    failed.append(f"Guild {guild.name}: channel {channel_id} missing")
                    continue

                try:
                    msg = await channel.fetch_message(msg_info["message_id"])
                    embed = await self.build_status_embed(guild)
                    await msg.edit(embed=embed)
                    updated += 1
                except discord.NotFound:
                    # Message deleted, remove from storage
                    failed.append(f"Guild {guild.name}, channel {channel.name}: message not found, removed")
                    del self.status_messages[guild_id][channel_id]
                    await self.save_status_messages()
                except Exception as e:
                    logger.error(f"Failed to update status message in {guild.name} #{channel.name}: {e}", exc_info=True)
                    failed.append(f"Guild {guild.name}, channel {channel.name}: error")

        msg = f"✅ Updated {updated} status message(s)."
        if failed:
            msg += "\n⚠️ Issues:\n" + "\n".join(failed)

        await interaction.followup.send(msg, ephemeral=True)

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        was_admin = before.id in ADMIN_USER_IDS
        is_admin_now = after.id in ADMIN_USER_IDS

        if not (was_admin or is_admin_now):
            return

        if before.status == after.status:
            return

        guild = after.guild
        guild_id = str(guild.id)

        if guild_id not in self.status_messages:
            return

        for channel_id_str, msg_info in list(self.status_messages[guild_id].items()):
            channel = guild.get_channel(int(channel_id_str))
            if not channel:
                continue

            try:
                msg = await channel.fetch_message(msg_info["message_id"])
                embed = await self.build_status_embed(guild)
                await msg.edit(embed=embed)
            except discord.NotFound:
                del self.status_messages[guild_id][channel_id_str]
                await self.save_status_messages()
            except Exception:
                pass  # optionally log errors

    async def build_status_embed(self, guild: discord.Guild) -> discord.Embed:
        uptime = datetime.datetime.utcnow() - self.bot.launch_time
        ping = round(self.bot.latency * 1000)
        users = sum(g.member_count for g in self.bot.guilds)
        memory = psutil.Process().memory_info().rss / 1024 / 1024

        try:
            listed = await db.get_car_count()
        except:
            listed = 0
        try:
            sticky = await db.get_sticky_count()
        except:
            sticky = 0
        try:
            registered = await db.get_registered_user_count()
        except:
            registered = 0
        try:
            top_brands = await db.get_top_brands()
        except:
            top_brands = []

        # Filter admins who are online and not bots
        admins = [
            member for member in guild.members
            if member.id in ADMIN_USER_IDS
            and member.status != discord.Status.offline
            and not member.bot
        ]

        brand_list = "\n".join([f"**{b}** — {c} cars" for b, c in top_brands]) or "No data"
        admin_mentions = ", ".join([admin.mention for admin in admins]) or "None online"

        color = discord.Color.red()

        embed = discord.Embed(
            title=f"{guild.name} Bot Status",
            description="**BP CARS Dashboard** — _Live & Thematic_",
            color=color
        )
        embed.set_thumbnail(url=guild.icon.url if guild.icon else discord.Embed.Empty)
        embed.add_field(name="🕒 Uptime", value=str(uptime).split('.')[0], inline=True)
        embed.add_field(name="📶 Ping", value=f"{ping}ms", inline=True)
        embed.add_field(name="🧠 Memory", value=f"{memory:.2f} MB", inline=True)
        embed.add_field(name="👥 Users", value=str(users), inline=True)
        embed.add_field(name="🚗 Cars Listed", value=str(listed), inline=True)
        embed.add_field(name="📝 Sticky Notes", value=str(sticky), inline=True)
        embed.add_field(name="🧾 Registered Users", value=str(registered), inline=True)
        embed.add_field(name="🛡️ Admins Online", value=admin_mentions, inline=False)
        embed.add_field(name="🏆 Top Brands", value=brand_list, inline=False)
        embed.add_field(
            name="⚙️ Slash Commands",
            value="\n".join([
                "`/car_add`", "`/car_all`", "`/car_list`",
                "`/car_update`", "`/status-create`", "`/status-update`", "`/alert`"
            ]),
            inline=False
        )
        timestamp = datetime.datetime.utcnow()
        embed.set_footer(
            text=f"Powered by BP CARS • {timestamp.strftime('%d/%m/%Y %H:%M')}",
            icon_url=self.bot.user.avatar.url if self.bot.user.avatar else discord.Embed.Empty
        )
        return embed


async def setup(bot):
    await bot.add_cog(StatusDashboard(bot))
