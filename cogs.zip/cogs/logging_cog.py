import discord
from discord.ext import commands
from discord import app_commands
from colorama import Fore, Style
import traceback
import sys

def log_console_success(msg):
    print(Fore.GREEN + Style.BRIGHT + f"`✅ {msg}`" + Style.RESET_ALL)

def log_console_error(msg):
    print(Fore.RED + Style.BRIGHT + f"`❌ {msg}`" + Style.RESET_ALL)

class LoggingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.log_channel_id = 1395203305772417125
        self.commands_synced = 0
        self.synced_once = False  # ensure on_ready only runs once

    @commands.Cog.listener()
    async def on_ready(self):
        if self.synced_once:
            return
        self.synced_once = True

        await self.bot.wait_until_ready()

        # Sync commands globally
        try:
            synced = await self.bot.tree.sync()
            self.commands_synced = len(synced)
            log_console_success(f"Globally synced {self.commands_synced} commands.")
        except Exception as e:
            await self.send_error_embed(f"Failed to sync commands: {e}", e)
            log_console_error(f"Failed to sync commands: {e}")

        # Send startup embed to log channel
        await self.send_startup_embed()

        # Log connection info to console
        log_console_success(f"Bot connected as {self.bot.user} (ID: {self.bot.user.id})")
        log_console_success(f"Connected to {len(self.bot.guilds)} guild(s)")
        log_console_success("Startup complete.")

    async def send_startup_embed(self):
        channel = self.bot.get_channel(self.log_channel_id)
        if channel is None:
            log_console_error(f"Failed to fetch log channel: ID {self.log_channel_id} not found")
            return

        embed = discord.Embed(
            title="🤖 Bot Started",
            description=(
                f"Bot: **Big Paulie's classic#3831** (ID: `{self.bot.user.id}`)\n"
                f"Connected Guilds: {len(self.bot.guilds)}\n"
                f"Commands Synced: {self.commands_synced}"
            ),
            color=discord.Color.red()
        )

        guilds_info_lines = []
        for guild in self.bot.guilds:
            line = f"📡 {guild.name}\nID: `{guild.id}`\nMembers: {guild.member_count}"
            guilds_info_lines.append(line)

        guilds_info = "\n\n".join(guilds_info_lines)
        if len(guilds_info) > 1024:
            guilds_info = guilds_info[:1021] + "..."

        embed.add_field(name="Guild Details", value=guilds_info, inline=False)

        avatar_url = self.bot.user.avatar.url if self.bot.user and self.bot.user.avatar else None
        embed.set_footer(
            text="Powered by Big Paulie's Classic Cars Admin",
            icon_url=avatar_url
        )

        try:
            await channel.send(embed=embed)
        except Exception as e:
            log_console_error(f"Failed to send startup embed to log channel: {e}")

    async def send_error_embed(self, message: str, exc: Exception = None):
        """Send an embed to the log channel with error info."""
        channel = self.bot.get_channel(self.log_channel_id)
        if channel is None:
            log_console_error(f"Failed to fetch log channel for error embed: ID {self.log_channel_id} not found")
            return

        embed = discord.Embed(
            title="❌ Bot Error",
            description=message,
            color=discord.Color.red()
        )
        if exc:
            tb = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            if len(tb) > 1024:
                tb = tb[:1021] + "..."
            embed.add_field(name="Traceback", value=f"```py\n{tb}```", inline=False)

        try:
            await channel.send(embed=embed)
        except Exception as send_exc:
            log_console_error(f"Failed to send error embed to log channel: {send_exc}")

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        # This only catches prefixed commands errors; slash command errors are different
        await self.send_error_embed(f"Error in command `{ctx.command}` invoked by {ctx.author}:\n{error}", error)
        log_console_error(f"Error in command {ctx.command} by {ctx.author}: {error}")

    @commands.Cog.listener()
    async def on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        # Slash command error handler
        await self.send_error_embed(
            f"Error in slash command `{interaction.command.name}` invoked by {interaction.user}:\n{error}", error
        )
        log_console_error(f"Error in slash command {interaction.command.name} by {interaction.user}: {error}")

    @commands.Cog.listener()
    async def on_app_command_completion(self, interaction: discord.Interaction, command: app_commands.Command):
        # Send a usage log to the channel for every slash command run
        channel = self.bot.get_channel(self.log_channel_id)
        if channel is None:
            log_console_error(f"Failed to fetch log channel for command usage log: ID {self.log_channel_id} not found")
            return

        embed = discord.Embed(
            title="🛠 Slash Command Used",
            color=discord.Color.green(),
            timestamp=interaction.created_at
        )
        embed.add_field(name="User", value=f"{interaction.user.mention} (`{interaction.user.id}`)", inline=True)
        embed.add_field(name="Command", value=f"`{command.qualified_name}`", inline=True)
        embed.add_field(name="Guild", value=f"{interaction.guild.name if interaction.guild else 'DM'} (`{interaction.guild_id}`)", inline=True)

        avatar_url = interaction.user.avatar.url if interaction.user.avatar else None
        embed.set_author(name=str(interaction.user), icon_url=avatar_url)
        embed.set_footer(text="Big Paulie's Classic Cars Admin")

        try:
            await channel.send(embed=embed)
        except Exception as e:
            log_console_error(f"Failed to send command usage embed: {e}")

async def setup(bot):
    await bot.add_cog(LoggingCog(bot))
