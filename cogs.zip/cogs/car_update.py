import discord
from discord import app_commands
from discord.ext import commands
from db import get_user_cars, update_car

class UpdateCarModal(discord.ui.Modal, title="Update Car Info"):
    make = discord.ui.TextInput(label="Make", max_length=100)
    model = discord.ui.TextInput(label="Model", max_length=100)
    year = discord.ui.TextInput(label="Year", max_length=4)
    status = discord.ui.TextInput(label="Status", max_length=100)

    def __init__(self, car_id, old_make, old_model, old_year, old_status):
        super().__init__()
        self.car_id = car_id
        self.make.default = old_make
        self.model.default = old_model
        self.year.default = str(old_year)
        self.status.default = old_status

    async def on_submit(self, interaction: discord.Interaction):
        try:
            year_int = int(self.year.value)
        except ValueError:
            await interaction.response.send_message("Year must be a valid number.", ephemeral=True)
            return

        try:
            await update_car(
                car_id=self.car_id,
                make=self.make.value,
                model=self.model.value,
                year=year_int,
                status=self.status.value
            )
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to update car: {e}", ephemeral=True)
            return

        await interaction.response.send_message("✅ Car updated successfully.", ephemeral=True)


class CarUpdateDropdown(discord.ui.Select):
    def __init__(self, cars):
        options = [
            discord.SelectOption(
                label=f"{car['make']} {car['model']} ({car['year']}) - {car['status']}",
                value=str(car['id'])
            )
            for car in cars
        ]
        super().__init__(placeholder="Select a car to update", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        car_id = int(self.values[0])
        car = next((c for c in self.view.cars if c['id'] == car_id), None)
        if car is None:
            await interaction.response.send_message("Car not found.", ephemeral=True)
            return

        modal = UpdateCarModal(
            car_id=car_id,
            old_make=car['make'],
            old_model=car['model'],
            old_year=car['year'],
            old_status=car['status']
        )
        await interaction.response.send_modal(modal)


class CarUpdateView(discord.ui.View):
    def __init__(self, cars):
        super().__init__(timeout=60)
        self.cars = cars
        self.add_item(CarUpdateDropdown(cars))


class CarUpdateCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="car_update", description="Update one of your cars")
    async def car_update(self, interaction: discord.Interaction):
        cars = await get_user_cars(interaction.user.id)
        if not cars:
            await interaction.response.send_message("You have no cars to update.", ephemeral=True)
            return

        view = CarUpdateView(cars)
        await interaction.response.send_message("Select a car to update:", view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(CarUpdateCog(bot))
