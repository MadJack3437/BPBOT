import discord
from discord.ext import commands
from discord import app_commands

BOT_OWNER_ID = 495587491697655829  # Replace with your Discord user ID
TARGET_GUILD_ID = 1353466278865797130  # Replace with your guild ID

guild_only = app_commands.guilds(discord.Object(id=TARGET_GUILD_ID))

# Owner check decorator
def is_owner():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id != BOT_OWNER_ID:
            raise app_commands.CheckFailure("You are not authorized to use this command.")
        return True
    return app_commands.check(predicate)


class SyncCog(commands.Cog):
    """Cog for syncing commands globally and to a specific guild."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._has_synced_on_ready = False

    def guild_only_command_names(self):
        return {"post-op-embed", "add-op", "clear-ops", "delete-op", "edit-op"}

    async def remove_guild_only_from_global(self):
        removed = []
        for cmd_name in self.guild_only_command_names():
            cmd = self.bot.tree.get_command(cmd_name)
            if cmd:
                try:
                    self.bot.tree.remove_command(cmd_name)
                    removed.append(cmd_name)
                except KeyError:
                    pass
        if removed:
            print(f"[SYNC] Removed guild-only commands from global tree: {', '.join(removed)}")

    @app_commands.command(name="sync", description="Sync guild-only commands to the target guild (owner only)")
    @is_owner()
    async def sync_guild(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            guild_obj = discord.Object(id=TARGET_GUILD_ID)
            synced = await self.bot.tree.sync(guild=guild_obj)
            cmd_names = [cmd.name for cmd in synced]
            await interaction.followup.send(
                f"✅ Synced {len(synced)} guild-only commands to guild {TARGET_GUILD_ID}: {', '.join(cmd_names)}",
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(f"❌ Guild sync failed: {e}", ephemeral=True)

    @app_commands.command(name="sync_global", description="Sync global commands globally (owner only)")
    @is_owner()
    async def sync_global(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            await self.remove_guild_only_from_global()
            synced = await self.bot.tree.sync()
            cmd_names = [cmd.name for cmd in synced]
            await interaction.followup.send(
                f"✅ Globally synced {len(synced)} commands (excluding guild-only): {', '.join(cmd_names)}",
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(f"❌ Global sync failed: {e}", ephemeral=True)

    @commands.Cog.listener()
    async def on_ready(self):
        if self._has_synced_on_ready:
            return
        self._has_synced_on_ready = True

        async def do_sync():
            try:
                await self.remove_guild_only_from_global()
                synced_global = await self.bot.tree.sync()
                print(f"[AUTO-SYNC] Globally synced {len(synced_global)} commands: {', '.join(cmd.name for cmd in synced_global)}")
            except Exception as e:
                print(f"[AUTO-SYNC] Failed to globally sync: {e}")

            try:
                guild_obj = discord.Object(id=TARGET_GUILD_ID)
                synced_guild = await self.bot.tree.sync(guild=guild_obj)
                print(f"[AUTO-SYNC] Synced {len(synced_guild)} guild-only commands: {', '.join(cmd.name for cmd in synced_guild)}")
            except Exception as e:
                print(f"[AUTO-SYNC] Failed guild sync: {e}")

        self.bot.loop.create_task(do_sync())


class GuildOnlyCommands(commands.Cog):
    """The 5 commands that should only appear in the target guild."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="post-op-embed", description="Post the OP embed")
    @guild_only
    async def post_op_embed(self, interaction: discord.Interaction):
        await interaction.response.send_message("Posted OP embed.", ephemeral=True)

    @app_commands.command(name="add-op", description="Add an OP rating")
    @guild_only
    async def add_op(self, interaction: discord.Interaction, user: discord.User, rating: int):
        await interaction.response.send_message(f"Added rating {rating} for {user.mention}.", ephemeral=True)

    @app_commands.command(name="clear-ops", description="Clear all OP ratings")
    @guild_only
    async def clear_ops(self, interaction: discord.Interaction):
        await interaction.response.send_message("Cleared all OP ratings.", ephemeral=True)

    @app_commands.command(name="delete-op", description="Delete OP rating for a user")
    @guild_only
    async def delete_op(self, interaction: discord.Interaction, user: discord.User):
        await interaction.response.send_message(f"Deleted rating for {user.mention}.", ephemeral=True)

    @app_commands.command(name="edit-op", description="Edit an OP rating")
    @guild_only
    async def edit_op(self, interaction: discord.Interaction, user: discord.User, rating: int):
        await interaction.response.send_message(f"Edited rating to {rating} for {user.mention}.", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(SyncCog(bot))
    await bot.add_cog(GuildOnlyCommands(bot))
