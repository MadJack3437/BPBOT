from discord.ext import commands
from discord import app_commands
import discord
import db  # Your db.py module

ALLOWED_USER_IDS = {495587491697655829, 987654321098765432}  # Replace with your admins

def is_allowed_user():
    def predicate(interaction: discord.Interaction) -> bool:
        return interaction.user.id in ALLOWED_USER_IDS
    return app_commands.check(predicate)

class DBReset(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="resetdb", description="Reset the database tables (restricted access)")
    @is_allowed_user()
    async def resetdb(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            await db.reset_db()
            await interaction.followup.send("✅ Database tables have been reset and recreated.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Failed to reset DB: {e}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(DBReset(bot))
