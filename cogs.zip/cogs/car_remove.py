import discord
from discord import app_commands
from discord.ext import commands
from db import get_user_cars, remove_car

class RemoveCarView(discord.ui.View):
    def __init__(self, cars):
        super().__init__(timeout=60)
        options = [
            discord.SelectOption(
                label=f"{car['make']} {car['model']} ({car['year']})",
                description=f"ID: {car['id']} Status: {car['status']}",
                value=str(car['id'])
            )
            for car in cars
        ]
        self.select = discord.ui.Select(
            placeholder="Select a car to remove...",
            options=options,
            custom_id="remove_car_select"
        )
        self.select.callback = self.select_callback
        self.add_item(self.select)
        self.selected_car_id = None

    async def select_callback(self, interaction: discord.Interaction):
        self.selected_car_id = int(self.select.values[0])
        await remove_car(self.selected_car_id)
        await interaction.response.edit_message(
            content=f"Car ID {self.selected_car_id} removed successfully! 🚗❌",
            view=None
        )
        self.stop()

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
        # Optionally edit the original message to disable the menu on timeout
        # But interaction response might not be possible here without context

class CarRemoveCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="removecar", description="Remove one of your cars")
    async def remove_car_command(self, interaction: discord.Interaction):
        cars = await get_user_cars(interaction.user.id)
        if not cars:
            await interaction.response.send_message("You have no cars to remove.", ephemeral=True)
            return
        view = RemoveCarView(cars)
        await interaction.response.send_message("Select a car to remove from the list below:", view=view, ephemeral=True)

async def setup(bot):
    await bot.add_cog(CarRemoveCog(bot))
