import discord
from discord import app_commands
from discord.ext import commands
from db import add_car, init_db_pool

class AddCarModal(discord.ui.Modal, title="Add a New Car"):
    make = discord.ui.TextInput(label="Make", placeholder="Toyota", max_length=100)
    model = discord.ui.TextInput(label="Model", placeholder="Corolla", max_length=100)
    year = discord.ui.TextInput(label="Year", placeholder="2020", max_length=4)
    status = discord.ui.TextInput(label="Status", placeholder="Available", max_length=100)

    def __init__(self):
        super().__init__()

    async def on_submit(self, interaction: discord.Interaction):
        try:
            year_int = int(self.year.value)
        except ValueError:
            await interaction.response.send_message("Year must be a valid number.", ephemeral=True)
            return

        try:
            await init_db_pool()
            await add_car(
                user_id=interaction.user.id,
                make=self.make.value,
                model=self.model.value,
                year=year_int,
                status=self.status.value,
            )
        except Exception as e:
            await interaction.response.send_message(f"❌ Failed to add car: {e}", ephemeral=True)
            return

        await interaction.response.send_message(
            f"✅ Car added: {self.make.value} {self.model.value} ({year_int}), Status: {self.status.value}",
            ephemeral=True
        )


class CarAddCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ready = False

    @commands.Cog.listener()
    async def on_ready(self):
        if self.ready:
            return
        self.ready = True
        await init_db_pool()

    @app_commands.command(name="car_add", description="Add a new car")
    async def car_add(self, interaction: discord.Interaction):
        modal = AddCarModal()
        await interaction.response.send_modal(modal)

async def setup(bot):
    await bot.add_cog(CarAddCog(bot))
