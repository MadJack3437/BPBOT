import discord
from discord import app_commands
from discord.ext import commands
from db import get_all_cars

class CarAllCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="car_all", description="List all cars")
    async def car_all(self, interaction: discord.Interaction):
        cars = await get_all_cars()  # No guild ID passed here
        if not cars:
            await interaction.response.send_message("No cars found.", ephemeral=True)
            return

        embed = discord.Embed(title="All Cars", color=discord.Color.red())
        for car in cars:
            embed.add_field(
                name=f"{car['make']} {car['model']} ({car['year']})",
                value=f"Status: {car['status']} | Added by <@{car['user_id']}>",
                inline=False
            )
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(CarAllCog(bot))
