import discord
from discord.ext import commands
from discord import app_commands

BOT_OWNER_ID = 495587491697655829  # Replace with your Discord user ID

def is_owner():
    async def predicate(interaction: discord.Interaction):
        return interaction.user.id == BOT_OWNER_ID
    return app_commands.check(predicate)

STATUS_CHOICES = [
    app_commands.Choice(name="online", value="online"),
    app_commands.Choice(name="idle", value="idle"),
    app_commands.Choice(name="dnd", value="dnd"),
    app_commands.Choice(name="invisible", value="invisible"),
]

ACTIVITY_CHOICES = [
    app_commands.Choice(name="Playing", value="playing"),
    app_commands.Choice(name="Watching", value="watching"),
    app_commands.Choice(name="Listening", value="listening"),
    app_commands.Choice(name="Competing", value="competing"),
]

class StatusManager(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @is_owner()
    @app_commands.command(
        name="set_bot_status",
        description="Set the bot's online status and activity"
    )
    @app_commands.describe(
        status="Bot status",
        activity_type="Activity type",
        activity_name="Name of the activity"
    )
    @app_commands.choices(
        status=STATUS_CHOICES,
        activity_type=ACTIVITY_CHOICES
    )
    async def set_bot_status(
        self,
        interaction: discord.Interaction,
        status: app_commands.Choice[str],
        activity_type: app_commands.Choice[str],
        activity_name: str
    ):
        await interaction.response.defer(ephemeral=True)

        valid_statuses = {
            "online": discord.Status.online,
            "idle": discord.Status.idle,
            "dnd": discord.Status.dnd,
            "invisible": discord.Status.invisible
        }

        chosen_status = valid_statuses.get(status.value)
        activity_type_value = activity_type.value.lower()

        if activity_type_value == "playing":
            activity = discord.Game(name=activity_name)
        elif activity_type_value == "watching":
            activity = discord.Activity(type=discord.ActivityType.watching, name=activity_name)
        elif activity_type_value == "listening":
            activity = discord.Activity(type=discord.ActivityType.listening, name=activity_name)
        elif activity_type_value == "competing":
            activity = discord.Activity(type=discord.ActivityType.competing, name=activity_name)
        else:
            await interaction.followup.send("❌ Invalid activity type.", ephemeral=True)
            return

        print(f"[DEBUG] Changing presence: status={chosen_status}, activity={activity}")

        try:
            await self.bot.change_presence(status=chosen_status, activity=activity)
            await interaction.followup.send(
                f"✅ Bot status set to **{status.name}** with activity: **{activity_type.name} {activity_name}**",
                ephemeral=True
            )
        except Exception as e:
            await interaction.followup.send(f"❌ Failed to change status: {e}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(StatusManager(bot))
