import discord
from discord.ext import commands
from discord import app_commands
import db

def format_rating_stars(score: int) -> str:
    return "⭐" * score + "✩" * (10 - score)

async def build_op_embed():
    ops = await db.get_all_ops()
    embed = discord.Embed(
        title="⚙️ Operator Ratings",
        description="List of Operators and their ratings (1-10)",
        color=discord.Color.blue()
    )

    if not ops:
        embed.add_field(name="No ratings yet", value="Use /add-op to add an operator rating.", inline=False)
        return embed

    for op in ops:
        user_mention = f"<@{op['user_id']}>"
        rating = op['rating']
        comment = op.get('comment', '') or 'No comment'
        embed.add_field(
            name=f"{user_mention} — {format_rating_stars(rating)} ({rating}/10)",
            value=comment,
            inline=False
        )
    return embed

class OPRatings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ratings_message_id = None
        self.ratings_channel_id = None

    async def cog_load(self):
        info = await db.get_op_embed_info()
        if info:
            self.ratings_channel_id = info["channel_id"]
            self.ratings_message_id = info["message_id"]

    @app_commands.command(name="post-op-embed", description="Post the OP Ratings embed in this channel")
    async def post_op_embed(self, interaction: discord.Interaction):
        embed = await build_op_embed()
        message = await interaction.channel.send(embed=embed)

        self.ratings_message_id = message.id
        self.ratings_channel_id = message.channel.id

        await db.save_op_embed_info(self.ratings_channel_id, self.ratings_message_id)

        await interaction.response.send_message("✅ OP Ratings embed posted and pinned.", ephemeral=True)

    @app_commands.command(name="add-op", description="Add or update an operator rating")
    @app_commands.describe(user="User to rate (ID or mention)", rating="Rating 1 to 10", comment="Optional comment")
    async def add_op(self, interaction: discord.Interaction, user: str, rating: int, comment: str = ""):
        await interaction.response.defer(ephemeral=True)
        # Parse user input to get user_id
        user_id = None
        if user.isdigit():
            user_id = int(user)
        elif user.startswith("<@") and user.endswith(">"):
            user_id = int(user.strip("<@!>"))
        else:
            await interaction.followup.send("❌ Invalid user input. Use user ID or mention.", ephemeral=True)
            return
        if not (1 <= rating <= 10):
            await interaction.followup.send("❌ Rating must be between 1 and 10.", ephemeral=True)
            return

        await db.add_or_update_op(user_id, rating, comment)

        # Refresh the embed message
        await refresh_op_embed(self.bot)

        await interaction.followup.send(f"✅ Rating for <@{user_id}> set to {rating}/10.", ephemeral=True)

async def refresh_op_embed(bot: commands.Bot):
    info = await db.get_op_embed_info()
    if not info:
        print("[OP EMBED] No message stored; skipping refresh.")
        return

    channel = bot.get_channel(info["channel_id"])
    if not channel:
        print("[OP EMBED] Channel not found.")
        return

    try:
        message = await channel.fetch_message(info["message_id"])
        embed = await build_op_embed()
        await message.edit(embed=embed)
        print("[OP EMBED] Embed refreshed.")
    except Exception as e:
        print(f"[OP EMBED] Failed to edit message: {e}")

async def setup(bot):
    cog = OPRatings(bot)
    await bot.add_cog(cog)
    await cog.cog_load()
