import discord
from discord import app_commands
from discord.ext import commands
from db import get_user_cars

class CarListCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="car_list", description="List your cars")
    async def car_list(self, interaction: discord.Interaction):
        cars = await get_user_cars(interaction.user.id)
        if not cars:
            await interaction.response.send_message("You have no cars.", ephemeral=True)
            return

        embed = discord.Embed(
            title=f"{interaction.user.name}'s Cars",
            color=discord.Color.red()
        )
        for car in cars:
            embed.add_field(
                name=f"{car.get('make', 'Unknown Make')} {car.get('model', 'Unknown Model')} ({car.get('year', 'Unknown Year')})",
                value=f"Status: {car.get('status', 'Unknown')} | ID: {car.get('id', 'N/A')}",
                inline=False
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(CarListCog(bot))
